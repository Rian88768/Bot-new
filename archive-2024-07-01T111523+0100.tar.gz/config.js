import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

// Owner dan Admin
global.owner = [
  ['6283179956449', 'Samsul', true],
  ['6283173000169']
] // nomor owner

global.mods = ['6283179956449']
global.prems = ['6283179956449', '6283173000169']

// API Prefix dan APIKey
global.APIs = {
  nrtm: 'https://fg-nrtm.ddns.net',
  lann: 'https://api.betabotz.eu.org',
  marin: 'https://api.marinkitagawa.toys', // Menambahkan API baru
}

global.APIKeys = {
  'https://api.betabotz.eu.org': 'p8ADYJib',
  'https://api.marinkitagawa.toys': 'admin123', // Menambahkan APIKey baru
}

// Tambahkan script global
global.marin = "admin123"
global.chara = "t-zssvBPlYLXR3PlMrzUhyu8h7p3vvUDWHwGybdWkKw"
global.lann = 'NEuhugHo'

// setting limit user
global.limit = 10

// Sticker WM
global.packname = 'YO-Md Bot|By sul' 
global.author = '@Sul' 
//--info NS [ NANS ]
global.NSnama = 'YO-Md SIMPLE BOT MD'
global.NSig = '-' 
global.NSgc = '-'
global.NSthumb = '-'

global.wait = '*⌛ _Loading..._*\n*▰▰▰▱▱▱▱▱*'
global.eror = 'Error, Kesalahan tidak terduga'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 

global.multiplier = 69 
global.maxwarn = '2' // max warning

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
