let handler = async (m, { conn, usedPrefix, command }) => {

    await conn.sendMessage(m.chat, { video: { url: dir[Math.floor(Math.random() * dir.length)] }, caption: `_Random opening anime_` }, { quoted: m })
}

handler.help = ['openinganime']
handler.tags = ['anime']
handler.command = /^(opanime|openinganime)$/i;
handler.diamond = true

export default handler

const dir = [
'https://l.top4top.io/m_2787ayfc40.mp4',
'https://telegra.ph/file/cdd18d2af8f4cb9633d37.mp4',
'https://c.top4top.io/m_2787u3o220.mp4',
'https://telegra.ph/file/6c109b4c8970ab3a87dc0.mp4',
'https://telegra.ph/file/f917f62fa927c4cfb09c9.mp4',
'https://telegra.ph/file/349f6a77b56c09dfc257e.mp4',
'https://telegra.ph/file/5486221c79786a2a6f2bf.mp4',
'https://telegra.ph/file/5cfd4ba782cf4d37343cc.mp4',
'https://telegra.ph/file/9be45f01dc873e1e22f45.mp4',
'https://telegra.ph/file/e0f440aa833d927b66fc6.mp4',
'https://telegra.ph/file/8dc86ed086806f69be12f.mp4',
'https://telegra.ph/file/daa45924cfb1114cadcea.mp4',
]